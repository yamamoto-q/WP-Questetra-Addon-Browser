(function($) {
  $(document).ready(function(){
    $(".addon_browser").each(function(index, el) {
    	var me = this;

    	var catalogName = $(this).data('catalog');
    	if(!catalogName){
    			return;
    	}
        var catalogJson = window[catalogName];
        if(!catalogJson){
        		return;
        }
        var catalog = JSON.parse(catalogJson);

        for (var i = catalog.length - 1; i >= 0; i--) {
        	console.log(catalog[i]);

        	var itemHtml = "<div>";

        	itemHtml += '<div style="background-image:url(' + catalog[i].img + ');">';
        	itemHtml += '</div>';

        	itemHtml += '<div>' + catalog[i].description + '</div>';
        	itemHtml += '<div>' + catalog[i].name + '</div>';
        	itemHtml += '<div>' + catalog[i].count + '</div>';

        	itemHtml += "</div>";

        	$(me).append(itemHtml);
        }
    });	
  });
})(window.jQuery);